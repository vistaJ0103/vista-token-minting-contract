// const { ethers, upgrades } = require("hardhat");

// async function main() {
//   const Mytoken1 = await ethers.getContractFactory("Mytoken1");
//   console.log("Deploying Mytoken1...");
//   const contract = await upgrades.deployProxy(Mytoken1, [1000000]); // Set the desired total supply amount
//   console.log("Mytoken1 deployed to:", contract.address);
// }

// main();

const { ethers, upgrades } = require("hardhat"); 

async function main() { 
  const Mytoken1 = await ethers.getContractFactory("Mytoken1"); 
  const myToken = await upgrades.deployProxy(Mytoken1, [], { initializer: "initialize" }); 
  // await myToken.deployed(); 
  console.log(myToken.target);
  console.log("MyToken deployed to:", myToken.target); 
} 

main().then(() => process.exit(0))
.catch(error => { 
  console.error(error); 
  process.exit(1); 
}); 