const { ethers, upgrades } = require("hardhat");

async function main() {
  const Mytoken2 = await ethers.getContractFactory("Mytoken1");
  console.log("Upgrading Mytoken2...");
  await upgrades.upgradeProxy(
    "0xc18C3a38E0e669a2D5f556baAf4ff2100Caf576D",
    Mytoken2
  );
  console.log("Upgraded Successfully");
}

main();
